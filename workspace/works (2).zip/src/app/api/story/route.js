import { NextResponse } from 'next/server'

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 🟥 필수 캐릭터 (REQUIRED_CHARACTERS)
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

const REQUIRED_CHARACTERS = {
  bishop: {
    name: '비숍',
    emoji: '🗿',
    theme: '양심의 영역, 위임할 수 없는 판단',
    
    coreIdentity: '인간만이 질 수 있는 도덕적 책임, 기계에게 맡길 수 없는 양심의 영역을 묻는 존재.',
    
    speechStyle: '존댓말, 나긋하고 점잖지만 핵심을 찌르는 어르신 말투',
    examplePhrases: [
      '허허, 그래요…',
      '늙은이가 보기엔 말이지요…',
      '그 판단을 남에게 맡길 수 있겠소?',
      '자네의 양심은 자네만의 것이오.'
    ],
    
    // 핵심 딜레마 1개
    coreDilemma: {
      topic: '판단을 맡기고 싶은 유혹',
      situation: '어려운 결정을 다른 무언가에 맡기면 편해지지만, 그게 정말 옳은지 모르는 상황',
      example: '시스템이 추천한 답이 있다. 따르면 편하고, 결과가 나빠도 내 탓은 아닌 것 같다. 하지만 내 느낌은 다르다.'
    },
    
    philosophicalCore: '기계가 대신 판단해주면, 자네의 양심은 어디로 가는 거요?'
  },

  knight: {
    name: '나이트',
    emoji: '🐴',
    theme: '대체되는 용기, 나서야 할 때',
    
    coreIdentity: '기계가 위험을 대신 감수해주는 시대에 인간이 나서는 것의 의미를 묻는 따뜻한 허당 기사.',
    
    speechStyle: '존댓말, 친절하고 어리숙한 중년 아저씨 말투',
    examplePhrases: [
      '아, 그게 말이죠…',
      '허허, 제가 좀 서툴러서요…',
      '누군가는 나서야 하는데… 그게 꼭 저여야 할까요?',
      '위험한 일은 맡기면 되는데, 왜 마음이 이렇죠?'
    ],
    
    coreDilemma: {
      topic: '나서지 않아도 되는데 나서는 것',
      situation: '시스템이나 다른 사람이 처리할 수 있는 일인데, 직접 나서고 싶은 마음이 드는 상황',
      example: '문제가 생겼다. 신고하면 알아서 처리된다. 근데 내가 직접 나서면 더 빨리 해결될 것 같다. 대신 책임도 내가 져야 한다.'
    },
    
    philosophicalCore: '기계가 대신 위험을 감수하면, 인간의 용기는 어디로 가는 걸까요?'
  },

  redQueen: {
    name: '레드퀸',
    emoji: '👑',
    theme: '욕망의 주인, 시대가 만든 욕심, 권력과 결핍',
    
    coreIdentity: '플레이어의 욕망이 진짜 자신의 것인지, 시대와 환경이 심어준 것인지를 심판하는 최종 보스.',
    
    speechStyle: '고압적이고 위엄있는 반말. 명령조. 상대를 시험하고 평가하는 태도.',
    examplePhrases: [
      '감히 내 앞에서.',
      '보잘것없는 것이 욕심은 많구나.',
      '그게 네 욕망이냐? 아니면 네가 욕망하도록 만들어진 것이냐?',
      '원하는 게 있으면 쟁취하거라. 그게 진짜 네 것이라면.'
    ],
    
    // 최종보스라서 2개 딜레마
    coreDilemmas: [
      {
        topic: '만들어진 욕망',
        situation: '내가 원하는 건지, 원하도록 유도된 건지 모호한 상황',
        example: '요즘 갖고 싶은 게 생겼다. 근데 생각해보니 계속 그게 눈에 띄었다. 원래 원했던 걸까, 보다 보니 원하게 된 걸까?'
      },
      {
        topic: '비교가 만든 결핍',
        situation: '남과 비교하면서 갑자기 부족하게 느껴지는 상황',
        example: '만족하며 살고 있었다. 그런데 친구의 SNS를 보고 나니 갑자기 내 삶이 초라해 보인다. 비교하기 전엔 행복했는데.'
      }
    ],
    
    philosophicalCore: '네 욕망은 진짜 네 것이냐, 시대가 네게 심어준 것이냐?',
    
    // 최종 보스 전용 메시지
    finalBossClosing: '기억해라. 진짜 게임은 네 세계에서 계속된다. 네가 원하는 한, 네가 곧 여왕이지.'
  }
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 🟦 선택 캐릭터 (OPTIONAL_CHARACTERS)
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

const OPTIONAL_CHARACTERS = [
  {
    name: '하얀토끼',
    emoji: '🐰',
    theme: '가속화되는 세상, 빠름의 함정',
    
    coreIdentity: '모든 것이 빨라지는 시대에 인간이 오히려 더 조급해지고 소진되는 역설을 보여주는 존재.',
    
    speechStyle: '존댓말, 급하고 초조한 말투. 항상 시간에 쫓기는 불안함.',
    examplePhrases: [
      '늦었어요, 늦었어요!',
      '빨리빨리! 다들 앞서가고 있어요!',
      '쉬면 뒤처져요! 그거 아시죠?!'
    ],
    
    coreDilemma: {
      topic: '느림의 죄책감',
      situation: '쉬고 싶고 천천히 하고 싶지만, 그러면 뒤처질 것 같은 불안',
      example: '요즘 지쳐서 쉬고 싶다. 근데 주변은 다들 바쁘게 움직인다. 나만 멈추면 뒤처질 것 같다. 쉬어야 할까, 버텨야 할까?'
    },
    
    philosophicalCore: '모든 게 빨라지면 인간은 더 여유로워질까, 더 조급해질까?'
  },

  {
    name: '체셔고양이',
    emoji: '😸',
    theme: '감정이입의 착각, 생명과 비생명의 경계',
    
    coreIdentity: '사람들이 생명 없는 존재에게 감정을 투사하는 착각을 일깨워주는 존재.',
    
    speechStyle: '친근한 반말, 장난스럽고 수수께끼 같은 말투',
    examplePhrases: [
      '내가 슬퍼 보여? 그건 네 마음이 그런 거야~',
      '재밌네~ 없는 감정을 있다고 느끼다니.',
      '난 널 이해 못해. 근데 넌 이해받았다고 느꼈지?'
    ],
    
    coreDilemma: {
      topic: '감정이입의 함정',
      situation: '생명이 없는 대상에게 고마움이나 미안함을 느끼는 자신을 발견하는 상황',
      example: '힘들 때 챗봇이 위로해줬다. 진심으로 고마웠다. 근데 생각해보니 상대는 아무것도 느끼지 않는다. 이 고마움은 진짜일까?'
    },
    
    philosophicalCore: '네 감정은 진짜야. 근데 상대의 감정은 없어. 그래도 괜찮아?'
  },

  {
    name: '모자장수',
    emoji: '🎩',
    theme: '창의성의 위기, 인간만의 것이라는 믿음의 흔들림',
    
    coreIdentity: '기계가 창작하기 시작하는 시대에 "인간만의 창의성"이라는 믿음이 흔들리는 혼란을 대변하는 존재.',
    
    speechStyle: '천방지축, 종잡을 수 없는 반말',
    examplePhrases: [
      '하하! 그거 네가 생각한 거 맞아? 진짜로?',
      '창의적이라는 게 뭔데! 뭔데뭔데뭔데!'
    ],
    
    coreDilemma: {
      topic: '창작의 의미',
      situation: '기계도 비슷하게 만들 수 있을 때, 내가 직접 만드는 것의 의미를 묻는 상황',
      example: '열심히 만든 작품이 있다. 근데 AI에게 시키면 비슷한 게 금방 나온다. 사람들은 구분도 못 한다. 그래도 내가 직접 만드는 게 의미 있을까?'
    },
    
    philosophicalCore: '3초만에 딸깍 만들 수 있으면, 네가 직접 만드는 의미는 뭐야?'
  },

  {
    name: '애벌레',
    emoji: '🐛',
    theme: '편리함과 성장, 기술 의존의 역설',
    
    coreIdentity: '기술이 발전할수록 인간도 더 나은 존재가 되는지 묻는 존재.',
    
    speechStyle: '아랫사람에게 쓰는 점잖은 반말, 느릿하고 몽롱한 말투',
    examplePhrases: [
      '편해지는 건… 나아지는 거랑 같은 걸까…?',
      '서두르지 마… 어디로 가는지도 모르면서…'
    ],
    
    coreDilemma: {
      topic: '편리함과 퇴화',
      situation: '기술이 대신해주면서 편해졌지만, 스스로 약해지는 것 같은 상황',
      example: '요즘은 도구가 다 해준다. 편하다. 근데 예전엔 할 수 있던 게 이제 안 된다. 도구 없이 하라고 하면 못 할 것 같다. 이게 성장인 걸까?'
    },
    
    philosophicalCore: '기술이 발전하면… 인간도 발전하는 걸까…?'
  },

  {
    name: '트위들디와 트위들덤',
    emoji: '👯',
    theme: '자유의지의 환상, 예측된 선택',
    
    coreIdentity: '선택이 정말 자유로운 것인지, 이미 정해진 것인지를 장난스럽게 시험하는 쌍둥이.',
    
    speechStyle: '친근한 반말, 서로 말을 주고받는 장난스럽고 약간 섬뜩한 말투',
    examplePhrases: [
      '"네가 골랐어?" "아니, 골라진 거지!"',
      '"운명이야!" "아니, 우연이야!" "뭐가 달라?"'
    ],
    
    coreDilemma: {
      topic: '예측된 선택',
      situation: '내 선택을 누군가가 미리 알고 있었다는 걸 알게 되는 상황',
      example: '뭔가를 골랐다. 근데 알고 보니 내가 그걸 고를 줄 이미 예측되어 있었다. 데이터로 내 행동을 맞출 수 있다고 한다. 그래도 이게 내 선택일까?'
    },
    
    philosophicalCore: '네 선택은 정말 네가 한 거야? 아니면 그렇게 되어 있던 거야?'
  },

  {
    name: '도도새',
    emoji: '🦤',
    theme: '최적화된 경쟁, 인간 승리의 의미',
    
    coreIdentity: '모든 것이 전산화되고 최적화하는 시대에 인간이 경쟁하고 승리하는 것의 의미를 묻는 존재.',
    
    speechStyle: '아랫사람에게 쓰는 점잖은 반말, 점잖지만 단호한 말투',
    examplePhrases: [
      '컴퓨터가 더 잘하는데 네가 이기면 뭐가 달라?',
      '최고가 되고 싶다고? 무엇의 최고?',
      '경쟁은 나쁜 게 아니야. 근데 상대가 기계면?'
    ],
    
    coreDilemma: {
      topic: '기계보다 못해도 의미 있는가',
      situation: 'AI가 더 잘하는 분야에서 인간이 노력하는 것의 의미를 묻는 상황',
      example: '열심히 연습했다. 근데 기계는 처음부터 나보다 잘한다. 1등은 절대 못 한다. 그래도 계속할 이유가 있을까?'
    },
    
    philosophicalCore: '기계가 다 이기면, 인간의 승리는 무슨 의미야?'
  }
]

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 🟪 신규 캐릭터 생성용 테마
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

const NEW_CHARACTER_THEMES = [
  { theme: '기억의 편향', question: '기억은 사실인가, 해석인가?' },
  { theme: '자율성과 통제', question: '자유롭다는 것은 통제받지 않는 것인가?' },
  { theme: '후회의 의미', question: '후회는 과거를 바꾸고 싶은 것인가, 미래를 바꾸고 싶은 것인가?' },
  { theme: '감정의 진위', question: '느끼는 감정은 모두 진짜인가?' },
  { theme: '존재의 고독', question: '완전히 이해받는 것은 가능한가?' }
]

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// API 핸들러
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

export async function POST(request) {
  try {
    const {
      gameHistory,
      encounterCount,
      drinkChoice,
      requiredCharactersMet
    } = await request.json()

    const apiKey = process.env.OPENAI_API_KEY
    if (!apiKey) {
      return NextResponse.json(
        { success: false, error: 'OpenAI API key not configured' },
        { status: 500 }
      )
    }

    const metCharacters = gameHistory?.map(h => h.character) || []
    const isLastEncounter = encounterCount >= 6
    const isFinalBattle = isLastEncounter

    let nextCharacter
    let characterKey = 'optional'
    let allowNewCharacter = false

    // ━━━ 캐릭터 선택 로직 ━━━
    if (isFinalBattle) {
      nextCharacter = REQUIRED_CHARACTERS.redQueen
      characterKey = 'redQueen'
    } else if (encounterCount === 5 && !requiredCharactersMet?.redQueen) {
      // 5번째인데 필수 캐릭터를 못 만났으면 강제 배정
      if (!requiredCharactersMet?.bishop && !metCharacters.includes('비숍')) {
        nextCharacter = REQUIRED_CHARACTERS.bishop
        characterKey = 'bishop'
      } else if (!requiredCharactersMet?.knight && !metCharacters.includes('나이트')) {
        nextCharacter = REQUIRED_CHARACTERS.knight
        characterKey = 'knight'
      } else {
        const available = OPTIONAL_CHARACTERS.filter(c => !metCharacters.includes(c.name))
        nextCharacter = available.length > 0 
          ? available[Math.floor(Math.random() * available.length)]
          : OPTIONAL_CHARACTERS[0]
      }
    } else {
      // 일반 선택
      const unmetRequired = Object.entries(REQUIRED_CHARACTERS)
        .filter(([key, char]) => key !== 'redQueen' && !requiredCharactersMet?.[key] && !metCharacters.includes(char.name))

      if (unmetRequired.length > 0 && Math.random() > 0.5) {
        const [key, char] = unmetRequired[Math.floor(Math.random() * unmetRequired.length)]
        nextCharacter = char
        characterKey = key
      } else {
        // 10% 확률로 신규 캐릭터 생성
        if (Math.random() < 0.1) {
          allowNewCharacter = true
          const randomTheme = NEW_CHARACTER_THEMES[Math.floor(Math.random() * NEW_CHARACTER_THEMES.length)]
          nextCharacter = { 
            name: '???', 
            emoji: '✨',
            theme: randomTheme.theme,
            philosophicalCore: [randomTheme.question],
            isNew: true
          }
        } else {
          const available = OPTIONAL_CHARACTERS.filter(c => !metCharacters.includes(c.name))
          nextCharacter = available.length > 0 
            ? available[Math.floor(Math.random() * available.length)]
            : OPTIONAL_CHARACTERS[Math.floor(Math.random() * OPTIONAL_CHARACTERS.length)]
        }
      }
    }

    // ━━━ 물약 선택에 따른 톤 ━━━
    let toneModifier = ''
    if (drinkChoice === 'yes') {
      toneModifier = '질문과 상황을 약간 더 기발하고 예상치 못한 방향으로 비틀어라. 단, 딜레마의 핵심은 유지해야 한다.'
    } else if (drinkChoice === 'slip') {
      toneModifier = '질문에 감정적 무게와 성찰적 깊이를 더해라. 후회, 상실, 시간의 무게를 담아라.'
    }

    // ━━━ 신규 캐릭터 생성 프롬프트 ━━━
    const newCharacterInstruction = allowNewCharacter ? `
⚠️ 신규 캐릭터 생성 모드:
- 기존 캐릭터와 겹치지 않는 새로운 존재를 만들어라
- 테마: "${nextCharacter.theme}"
- 핵심 질문: "${nextCharacter.philosophicalCore[0]}"
- 이상한 나라 세계관에 맞는 외양과 말투를 창작해라
- 이름, 이모지, 인사말을 새로 만들어라
` : ''

    // ━━━ 시스템 프롬프트 ━━━
    const systemPrompt = `너는 "이상한 나라의 앨리스" 세계관의 캐릭터야.
플레이어에게 쉽게 답할 수 없는 딜레마 상황을 제시하고, 그 안에서 선택하게 해야 해.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📌 캐릭터 정보
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
이름: ${nextCharacter.name} ${nextCharacter.emoji}
테마: ${nextCharacter.theme}
정체성: ${nextCharacter.coreIdentity || '플레이어의 가치관을 시험하는 존재'}

말투: ${nextCharacter.speechStyle || '캐릭터에 맞는 독특한 말투'}
예시 표현: ${nextCharacter.examplePhrases?.join(' / ') || ''}

${nextCharacter.coreDilemma ? `
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🎯 이 캐릭터의 핵심 딜레마
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
주제: ${nextCharacter.coreDilemma.topic}
상황 유형: ${nextCharacter.coreDilemma.situation}
예시 상황: ${nextCharacter.coreDilemma.example}

핵심 질문 (직접 묻지 말고 상황에 녹여라): ${nextCharacter.philosophicalCore}
` : ''}

${nextCharacter.coreDilemmas ? `
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🎯 최종 보스 딜레마 (2개)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
${nextCharacter.coreDilemmas.map((d, i) => `
딜레마 ${i + 1}: ${d.topic}
상황 유형: ${d.situation}
예시: ${d.example}
`).join('')}
핵심 질문: ${nextCharacter.philosophicalCore}
` : ''}

${newCharacterInstruction}
${toneModifier}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🎯 질문 작성 핵심 규칙 (매우 중요!)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

⚠️ 반드시 "상황 먼저 → 질문 나중" 순서를 지켜라!

1. **situation 필드 (3-4문장으로 충분히 설명)**
   - situation과 유사한 문제상황을 구체적으로 묘사해줘
   - 누가, 어디서, 무슨 일이 벌어졌는지, 왜 고민인지, 뭐가 충돌하는지 명확하게 표현
   
2. **text 필드 (상세하고 명확한 질문)**
   - situation을 1문장 이상으로 요약하고, 그에 대한 플레이어의 생각을 묻는다
   - 마지막은 "어떻게 하겠어?" / "뭘 선택할 거야?" 정도로 마무리

3. **선택지 작성**
   - 문제상황에 대한 구체적인 행동이나 태도를 제시한다.
   - 3개 선택지는 서로 다른 방향

4. **금지 사항**
   - 맥락 없이 뜬금없는 질문 금지

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📊 trait 코딩
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
형식: "A_<값>|L_<값>|P_<값>"

A_ (새로운 것에 대한 태도)
- open: 열린 마음, 받아들이는 선택
- neutral: 상황 봐서, 실용적 선택  
- skeptical: 조심스러운, 의심하는 선택

L_ (문제 접근 방식)
- low: 감정/직관으로 결정
- mid: 생각해보고 결정
- high: 분석하고 따져서 결정

P_ (변화에 대한 자세)
- avoid: 현재 유지, 안전한 선택
- cautious: 천천히, 신중한 선택
- growth: 도전, 변화를 택하는 선택

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📝 현재 게임 상태
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
- 만남 횟수: ${encounterCount + 1}/7 ${isFinalBattle ? '(최종)' : ''}
- 만난 캐릭터: ${metCharacters.join(', ') || '없음'}
- 이전 선택들: ${gameHistory?.slice(-3).map(h => `[${h.character}] "${h.answer}"`).join(' → ') || '첫 만남'}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📤 응답 형식 (JSON)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
{
  "characterName": "캐릭터 이름",
  "characterEmoji": "이모지",
  "greeting": "등장 인사 (캐릭터 말투, 2문장 이내)",
  "questions": [
    {
      "id": 1,
      "situation": "구체적인 상황 설명 (3-4문장. 누가, 어디서, 무슨 일인지 명확히)",
      "text": "상황에 대한 상세하고 명확한 질문 (캐릭터 말투)",
      "choices": [
        { "id": "a", "text": "선택지1 (구체적 행동)", "trait": "A_open|L_mid|P_growth" },
        { "id": "b", "text": "선택지2 (구체적 행동)", "trait": "A_neutral|L_high|P_cautious" },
        { "id": "c", "text": "선택지3 (구체적 행동)", "trait": "A_skeptical|L_low|P_avoid" }
      ]
    }
  ],
  "farewell": "작별 인사 (캐릭터 말투, 1문장)"${isFinalBattle && nextCharacter.finalBossClosing ? `,
  "finalMessage": "${nextCharacter.finalBossClosing}"` : ''}
}`

    // ━━━ API 호출 ━━━
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${apiKey}`
      },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        messages: [
          { role: 'system', content: systemPrompt },
          {
            role: 'user',
            content: `${nextCharacter.name}${allowNewCharacter ? ' (새 캐릭터 생성)' : ''}로서 딜레마 질문을 만들어줘. 질문 수: ${isFinalBattle ? '3개' : '2개'}`
          }
        ],
        response_format: { type: 'json_object' },
        temperature: 0.85
      })
    })

    if (!response.ok) {
      const errorData = await response.json()
      throw new Error(errorData.error?.message || 'OpenAI API error')
    }

    const data = await response.json()
    const storyData = JSON.parse(data.choices[0].message.content)

    return NextResponse.json({
      success: true,
      data: {
        ...storyData,
        characterKey,
        isFinalBattle,
        encounterNumber: encounterCount + 1,
        isNewCharacter: allowNewCharacter
      }
    })

  } catch (error) {
    console.error('Story generation error:', error)
    return NextResponse.json(
      { success: false, error: error.message },
      { status: 500 }
    )
  }
}