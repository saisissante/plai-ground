'use client'

import { create } from 'zustand'
import { persist } from 'zustand/middleware'

const initialPosition = [
  ['', '', '', '', '', '', '', ''],
  ['', '', '', '', '', '', '', ''],
  ['', '', '', '', '', '', '', ''],
  ['', '', '', '', '', '', '', ''],
  ['', '', '', '', '', '', '', ''],
  ['', '', '', '', '', '', '', ''],
  ['', '', '', '', '', '', '', ''],
  ['', '', '', '', '', '', '', ''],
]

const useGameStore = create(
  persist(
    (set, get) => ({

      // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
      // 🔰 초기 상태
      // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
      gamePhase: 'intro',
      encounterCount: 0,
      currentPosition: initialPosition,
      currentEncounter: null,
      currentQuestionIndex: 0,

      // 👇 NEW: gameHistory는 "persist 대상에서 완전히 제외"
      gameHistory: [],

      requiredCharactersMet: { bishop: false, knight: false, redQueen: false },
      drinkChoice: null,
      endingData: null,
      isLoading: false,
      error: null,

      // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
      // 🔧 게임 시작 (여기서 기록도 초기화됨)
      // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
      startGame: () =>
        set({
          gamePhase: 'playing',
          encounterCount: 0,
          gameHistory: [],               // 🔥 초기화
          currentEncounter: null,
          currentQuestionIndex: 0,
          requiredCharactersMet: { bishop: false, knight: false, redQueen: false },
          error: null,
        }),

      // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
      // 🍷 시작 선택 저장
      // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
      setDrinkChoice: (choice) => set({ drinkChoice: choice }),

      // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
      // 🧭 만남 시작
      // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
      startEncounter: async () => {
        const { encounterCount, gameHistory, drinkChoice, requiredCharactersMet } = get()

        set({ isLoading: true, error: null })

        try {
          const response = await fetch('/api/story', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              gameHistory,
              encounterCount,
              drinkChoice,
              requiredCharactersMet,
            }),
          })

          const result = await response.json()
          if (!response.ok || !result.success) {
            throw new Error(result.error || '스토리 생성 실패')
          }

          const story = result.data

          // 필수 캐릭터 만남 체크
          const updatedRequired = { ...requiredCharactersMet }
          if (story.characterKey === 'bishop') updatedRequired.bishop = true
          if (story.characterKey === 'knight') updatedRequired.knight = true
          if (story.characterKey === 'redQueen') updatedRequired.redQueen = true

          set({
            currentEncounter: story,
            currentQuestionIndex: 0,
            encounterCount: encounterCount + 1,
            requiredCharactersMet: updatedRequired,
          })
        } catch (err) {
          console.error('Encounter Error:', err)
          set({ error: err.message })
        } finally {
          set({ isLoading: false })
        }
      },

      // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
      // 🎯 선택 처리
      // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
      selectChoice: (choice) => {
        const { currentEncounter, currentQuestionIndex } = get()

        if (!currentEncounter) return

        const currentQuestion = currentEncounter.questions[currentQuestionIndex]

        // 기록 추가
        const historyEntry = {
          character: currentEncounter.characterName,
          characterEmoji: currentEncounter.characterEmoji,
          question: currentQuestion?.text,
          answer: choice.text,
          trait: choice.trait,
          encounterNumber: currentEncounter.encounterNumber,
        }

        set((state) => ({
          gameHistory: [...state.gameHistory, historyEntry],
        }))

        // 다음 질문으로 이동
        const nextIndex = currentQuestionIndex + 1
        if (nextIndex < currentEncounter.questions.length) {
          set({ currentQuestionIndex: nextIndex })
        } else {
          // 모든 질문 종료 → 다음 만남 준비
          set({ currentEncounter: null, currentQuestionIndex: 0 })
        }
      },

      // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
      // 🏁 엔딩 생성
      // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
      generateEnding: async () => {
        const { gameHistory, drinkChoice } = get()
        set({ isLoading: true, error: null })

        try {
          const response = await fetch('/api/ending', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ gameHistory, drinkChoice }),
          })

          const result = await response.json()
          if (!response.ok || !result.success) {
            throw new Error(result.error || '엔딩 생성 실패')
          }

          set({ endingData: result.data })
        } catch (err) {
          console.error('Ending Error:', err)
          set({ error: err.message })
        } finally {
          set({ isLoading: false })
        }
      },

      // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
      // 🔄 게임 리셋
      // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
      resetGame: () =>
        set({
          gamePhase: 'intro',
          encounterCount: 0,
          currentPosition: initialPosition,
          currentEncounter: null,
          currentQuestionIndex: 0,
          gameHistory: [],               // 🔥 완전 초기화
          requiredCharactersMet: { bishop: false, knight: false, redQueen: false },
          endingData: null,
          drinkChoice: null,
          isLoading: false,
          error: null,
        }),
    }),

    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // 💾 persist 설정
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    {
      name: 'wonderland-game-storage',

      // ⛔ 여기서 gameHistory를 제외하는 것이 핵심!
      partialize: (state) => ({
        gamePhase: state.gamePhase,
        encounterCount: state.encounterCount,
        currentPosition: state.currentPosition,
        requiredCharactersMet: state.requiredCharactersMet,
        drinkChoice: state.drinkChoice,
        endingData: state.endingData,
      }),
    }
  )
)

export default useGameStore
