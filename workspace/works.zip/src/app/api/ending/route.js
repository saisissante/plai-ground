import { NextResponse } from 'next/server'

// 점수 계산 함수
function calculateScores(gameHistory) {
  const scores = {
    attitude: { open: 0, neutral: 0, skeptical: 0 },
    literacy: { low: 0, mid: 0, high: 0 },
    preparedness: { avoid: 0, cautious: 0, growth: 0 }
  }

  gameHistory?.forEach(h => {
    if (!h.trait) return
    
    // trait 형식: "A_open|L_high|P_growth"
    const parts = h.trait.split('|')
    parts.forEach(part => {
      const [axis, value] = part.split('_')
      if (axis === 'A' && scores.attitude[value] !== undefined) {
        scores.attitude[value]++
      } else if (axis === 'L' && scores.literacy[value] !== undefined) {
        scores.literacy[value]++
      } else if (axis === 'P' && scores.preparedness[value] !== undefined) {
        scores.preparedness[value]++
      }
    })
  })

  return scores
}

// 각 축별 지배적 성향 찾기
function getDominant(axisScores) {
  let maxKey = Object.keys(axisScores)[0]
  let maxVal = axisScores[maxKey]
  
  for (const [key, val] of Object.entries(axisScores)) {
    if (val > maxVal) {
      maxKey = key
      maxVal = val
    }
  }
  return { dominant: maxKey, score: maxVal, total: Object.values(axisScores).reduce((a, b) => a + b, 0) }
}

// 적응도 점수 계산 (0-100)
function calculateAdaptabilityScore(scores) {
  const attitudeResult = getDominant(scores.attitude)
  const literacyResult = getDominant(scores.literacy)
  const prepResult = getDominant(scores.preparedness)

  // 각 축별 점수 가중치
  const attitudePoints = { open: 35, neutral: 25, skeptical: 15 }
  const literacyPoints = { high: 35, mid: 25, low: 15 }
  const prepPoints = { growth: 30, cautious: 20, avoid: 10 }

  const baseScore = 
    attitudePoints[attitudeResult.dominant] + 
    literacyPoints[literacyResult.dominant] + 
    prepPoints[prepResult.dominant]

  // 일관성 보너스 (같은 방향성이면 +5~10점)
  let consistencyBonus = 0
  const positiveCount = [
    attitudeResult.dominant === 'open',
    literacyResult.dominant === 'high',
    prepResult.dominant === 'growth'
  ].filter(Boolean).length

  if (positiveCount === 3) consistencyBonus = 10
  else if (positiveCount === 2) consistencyBonus = 5

  return Math.min(100, baseScore + consistencyBonus)
}

// 사용자 유형 정의
function defineUserType(scores, adaptabilityScore) {
  const attitude = getDominant(scores.attitude).dominant
  const literacy = getDominant(scores.literacy).dominant
  const prep = getDominant(scores.preparedness).dominant

  // 형용사 결정
  const adjectives = {
    // 태도 기반
    open: ['열린', '포용적인', '수용적인'],
    neutral: ['균형잡힌', '실용적인', '중립적인'],
    skeptical: ['신중한', '비판적인', '조심스러운'],
    // 리터러시 기반
    high: ['분석적인', '논리적인', '체계적인'],
    mid: ['사려깊은', '통찰력있는', '이해력있는'],
    low: ['직관적인', '감성적인', '본능적인'],
    // 준비성 기반
    growth: ['진취적인', '도전적인', '성장지향적인'],
    cautious: ['안정적인', '계획적인', '점진적인'],
    avoid: ['보수적인', '전통적인', '신중한']
  }

  // 명사 결정 (조합 기반)
  const nouns = {
    'open_high_growth': '개척자',
    'open_high_cautious': '전략가',
    'open_high_avoid': '관찰자',
    'open_mid_growth': '모험가',
    'open_mid_cautious': '탐험가',
    'open_mid_avoid': '수용자',
    'open_low_growth': '몽상가',
    'open_low_cautious': '낙천가',
    'open_low_avoid': '순응자',
    'neutral_high_growth': '실용주의자',
    'neutral_high_cautious': '분석가',
    'neutral_high_avoid': '검토자',
    'neutral_mid_growth': '균형자',
    'neutral_mid_cautious': '중재자',
    'neutral_mid_avoid': '방관자',
    'neutral_low_growth': '적응자',
    'neutral_low_cautious': '생존자',
    'neutral_low_avoid': '관망자',
    'skeptical_high_growth': '혁신가',
    'skeptical_high_cautious': '비평가',
    'skeptical_high_avoid': '회의론자',
    'skeptical_mid_growth': '개혁자',
    'skeptical_mid_cautious': '감시자',
    'skeptical_mid_avoid': '보호자',
    'skeptical_low_growth': '저항자',
    'skeptical_low_cautious': '수호자',
    'skeptical_low_avoid': '은둔자'
  }

  const key = `${attitude}_${literacy}_${prep}`
  const noun = nouns[key] || '여행자'

  // 형용사 선택 (점수 높은 축에서)
  let adjective
  if (adaptabilityScore >= 70) {
    adjective = adjectives[attitude][0]
  } else if (adaptabilityScore >= 50) {
    adjective = adjectives[literacy][1]
  } else {
    adjective = adjectives[prep][2]
  }

  return `${adjective} ${noun}`
}

// 적응도 등급 결정
function getAdaptabilityGrade(score) {
  if (score >= 85) return { grade: 'S', label: '완벽한 적응력', color: '#FFD700' }
  if (score >= 70) return { grade: 'A', label: '뛰어난 적응력', color: '#4CAF50' }
  if (score >= 55) return { grade: 'B', label: '양호한 적응력', color: '#2196F3' }
  if (score >= 40) return { grade: 'C', label: '보통의 적응력', color: '#FF9800' }
  return { grade: 'D', label: '발전 가능성', color: '#9E9E9E' }
}

export async function POST(request) {
  try {
    const { gameHistory, drinkChoice } = await request.json()

    const apiKey = process.env.OPENAI_API_KEY
    if (!apiKey) {
      return NextResponse.json(
        { success: false, error: 'OpenAI API key not configured' },
        { status: 500 }
      )
    }

    // 점수 계산
    const scores = calculateScores(gameHistory)
    const adaptabilityScore = calculateAdaptabilityScore(scores)
    const userType = defineUserType(scores, adaptabilityScore)
    const gradeInfo = getAdaptabilityGrade(adaptabilityScore)

    // 각 축별 결과
    const attitudeResult = getDominant(scores.attitude)
    const literacyResult = getDominant(scores.literacy)
    const prepResult = getDominant(scores.preparedness)

    const systemPrompt = `너는 "이상한 나라의 앨리스" 여정을 마친 플레이어에게 결과를 알려주는 해설자야.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📊 플레이어 분석 결과
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

🎭 사용자 유형: ${userType}
📈 AI사회 적응도: ${adaptabilityScore}점 (${gradeInfo.grade}등급 - ${gradeInfo.label})

[세부 성향]
1. 새로운 것에 대한 태도: ${attitudeResult.dominant} 
   (open: 열린 마음 / neutral: 상황 판단 / skeptical: 신중한 접근)
   
2. 문제 접근 방식: ${literacyResult.dominant}
   (high: 분석적 / mid: 균형적 / low: 직관적)
   
3. 변화에 대한 자세: ${prepResult.dominant}
   (growth: 적극 수용 / cautious: 신중한 수용 / avoid: 현상 유지)

[선택 기록]
${gameHistory?.map(h => `- [${h.character}] ${h.question} → "${h.answer}"`).join('\n') || '(기록 없음)'}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
✍️ 작성 규칙
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1. **endingMessage**: 플레이어의 여정을 요약하는 메시지
   - 반드시 3줄 이내 (줄바꿈 2번까지)
   - 100자 이내
   - 플레이어의 선택 경향을 반영
   - 따뜻하고 격려하는 톤
   - 기술 용어 사용 금지

2. **typeDescription**: 사용자 유형에 대한 한 줄 설명
   - 20자 이내
   - "${userType}"이 어떤 사람인지 짧게 설명

3. **advice**: 앞으로의 조언
   - 1문장
   - 30자 이내
   - 구체적이고 실용적으로

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
응답 형식 (JSON)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
{
  "endingMessage": "3줄 이내 메시지",
  "typeDescription": "유형 한 줄 설명",
  "advice": "한 문장 조언"
}`

    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: '플레이어의 여정 결과를 작성해줘.' }
        ],
        response_format: { type: 'json_object' },
        temperature: 0.8,
      }),
    })

    if (!response.ok) {
      const errorData = await response.json()
      throw new Error(errorData.error?.message || 'OpenAI API error')
    }

    const data = await response.json()
    const llmResponse = JSON.parse(data.choices[0].message.content)
    
    return NextResponse.json({
      success: true,
      data: {
        // 계산된 데이터
        userType,
        adaptabilityScore,
        grade: gradeInfo.grade,
        gradeLabel: gradeInfo.label,
        gradeColor: gradeInfo.color,
        
        // 세부 점수
        scores: {
          attitude: {
            dominant: attitudeResult.dominant,
            detail: scores.attitude
          },
          literacy: {
            dominant: literacyResult.dominant,
            detail: scores.literacy
          },
          preparedness: {
            dominant: prepResult.dominant,
            detail: scores.preparedness
          }
        },
        
        // LLM 생성 텍스트
        endingMessage: llmResponse.endingMessage,
        typeDescription: llmResponse.typeDescription,
        advice: llmResponse.advice
      }
    })

  } catch (error) {
    console.error('Ending generation error:', error)
    return NextResponse.json(
      { success: false, error: error.message },
      { status: 500 }
    )
  }
}